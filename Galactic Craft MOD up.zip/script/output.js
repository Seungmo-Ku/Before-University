var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var DP = ctx.getResources().getDisplayMetrics().density;
var CountDown = 0;
var Mars = 0;
var dir;
var makeCool = 60*20;
var el = {
	send : false,
	sender : null,
	target : null,
	CoalG : 0, //Coal Generator
	CircuitF : 0, //Circuit Fabricator
	Compressor : 0, //Compressor
	EnergyS : 0,
	OxygenC : 0,
	OxygenZ : 0,
	Refinery : 0,
	FeulL : 0,
	okay : 0
}; //전기
var ox = {
	send : false,
	receive : false,
	C : 0, //수집기
	Z : 0 //압축기
};
var saveC = 20*20;
function readFile(path){
try{
var channel=new java.io.FileInputStream(path).getChannel();
var buffer=java.nio.ByteBuffer.allocate(channel.size());
channel.read(buffer);
channel.close();
return new java.lang.String(buffer.array());
}catch(e){clientMessage(e);}
}

function writeFile(path,str){
try{
var channel=new java.io.FileOutputStream(path).getChannel();
var buffer=java.nio.ByteBuffer.allocate(new java.lang.String(str).getBytes().length);
buffer.put(new java.lang.String(str).getBytes());
buffer.clear();
channel.write(buffer);
channel.close();
}catch(e){clientMessage(e);}
}
function readURL(url) {
	try {
		var URLContent = "";
		var bufferedReader = new java.io.BufferedReader(new java.io.InputStreamReader(java.net.URL(url).openStream()));
		
		var temp = "";
		while ((temp = bufferedReader.readLine()) != null) {
			URLContent += (URLContent == "" ? temp :  "\n" + temp);
		}
		bufferedReader.close();
		
		return URLContent;
	} catch(e) {
		print("인터넷 연결이 끊어져있거나 링크가 올바르지 않습니다.");
	}
}function UserName (){
	var txt = readFile ("/sdcard/games/com.mojang/minecraftpe/options.txt").toString ();
	var r1 = txt.split ("\n") [0];
	var r2 = r1.split (":") [1].toString ();
	return r2;
}
var enableL = readURL ("https://raw.githubusercontent.com/acsiper/ScriptManager/master/EnableList").toString ();
var pass = false;

var rr = enableL.split (",");
var n = UserName ();
for (var bb in rr){
	if (rr [bb] == n){
		pass = true;
		print ("정품 인증 완료");
	}
}
if (!pass){
	print ("정품이 아니십니다. 스크립트를 강제 종료합니다.");
}
var bw = null;
function createWindow() {
ctx.runOnUiThread(new java.lang.Runnable({
run: function () { 
try { 
var lay = new android.widget.LinearLayout(ctx); lay.setOrientation (1);
lay.setGravity(android.view.Gravity.CENTER); 
var btn1 = new android.widget.Button(ctx); 
btn1.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 88, DP * 48)); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () { 
//web ("http://m.blog.naver.com/hjms1099/220538787907");
web ("http://naver.me/58PiEMEJ");
}
}));
btn1.setText("Lecture");
lay.addView(btn1); 
var btn2 = new android.widget.Button(ctx); 
btn2.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 88, DP * 48)); 
btn2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () { 
ItemCode ();
}
}));
btn2.setText("Item code");
//lay.addView(btn2); 
bw = new android.widget.PopupWindow(lay, -2, -2); 
bw.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 0, DP * 50); 
} catch (e) {
print(e);
}
}
}));
}
function ItemCode(){ 
for (var aa=501; aa <602; aa++){
		if (Item.isValidItem (aa)){
			Player.addItemCreativeInv(aa, 1, 0);
		}
	}for (var aa=221; aa <240; aa++){
		if (Item.isValidItem (aa)){
			Player.addItemCreativeInv(aa, 1, 0);
		}
	}
	Player.addItemCreativeInv(212, 1, 0);
	Player.addItemCreativeInv(213, 1, 0);
	Player.addItemCreativeInv(214, 1, 0);
	Player.addItemCreativeInv(215, 1, 0);
var str = "";
for (var aa = 212; aa <240; aa++){
	if (Item.isValidItem (aa)){
		str += Item.getName (aa) + " : "+aa+"\n";
		}
}for (var aa = 501; aa <602; aa++){
	if (Item.isValidItem (aa)){
		str += Item.getName (aa) + " : "+aa+"\n";
		}
}
ctx.runOnUiThread( new java.lang.Runnable({
run: function(){
try{
new android.app.AlertDialog.Builder(ctx)

.setTitle("Item Code")
.setMessage("" + str)
.setPositiveButton("확인",new android.content.DialogInterface.OnClickListener({onClick:function(){

}}))
.create().show();
}catch(e){
clientMessage(e);
}
}}));
}
function leaveGame (){
	ctx.runOnUiThread (new java.lang.Runnable ({ run:function (){
		bw.dismiss ();
		bw = null;
		}}));
}
function web (url){
	ctx.runOnUiThread(new java.lang.Runnable({run:function(){
		webGUI = new android.widget.PopupWindow();
		var webLayout = new android.widget.LinearLayout(ctx);
		var webView = new android.webkit.WebView(ctx);
		var closeButton = new android.widget.Button(ctx);
		var webSet = webView.getSettings();
		webSet.setJavaScriptEnabled (true);
		webView.setWebChromeClient (new android.webkit.WebChromeClient ());
		webView.setWebViewClient (new android.webkit.WebViewClient ());
		webView.loadUrl (url);
		webGUI.setFocusable (true);
		webView.setFocusableInTouchMode (true);
		closeButton.setWidth(ctx.getScreenWidth ());
		closeButton.setText ("Off");
		closeButton.setBackgroundDrawable (new android.graphics.drawable.ColorDrawable (android.graphics.Color.parseColor ("#FF9800")));
		
		webLayout.addView (webView);
	//	webLayout.addView (closeButton);
		webLayout.setOrientation (1);
		webGUI.setContentView (webLayout);
		webGUI.setWidth (ctx.getScreenWidth ()/1.2);
		webGUI.setHeight(ctx.getScreenHeight ()/1.2);
webGUI.setBackgroundDrawable (new android.graphics.drawable.ColorDrawable (android.graphics.Color.argb(255, 255, 255, 255)));
		webGUI.showAtLocation (ctx.getWindow ().getDecorView (), android.view.Gravity.CENTER | android.view.Gravity.CENTER, 0, 0);
		closeButton.setOnClickListener(new android.view.View.OnClickListener({
			onClick:function(){
				webGUI.dismiss()}}))}}))
		
		}

var ax, ay, az;
var bx, by, bz;
//전력






function newLevel (){
	if (!pass){
		return;
	}
	ModPE.setItem (501, "airFan", 0, "Air Fan", 1);
ModPE.setItem (502, "airVent", 0, "Air Vent", 1);
ModPE.setItem (503, "battery", 0, "Battery", 1);

ModPE.setItem (504, "buggymat_seat", 0, "Buggymat Seat", 1);
ModPE.setItem (505, "buggymat_storage", 0, "Buggymat Storage", 1);
ModPE.setItem (506, "buggymat_wheel", 0, "Buggymat Wheel", 1);
ModPE.setItem (507, "canister_copper", 0, "Copper Canister");
ModPE.setItem (508, "canister_tin", 0, "Tin Canister");
ModPE.setItem (509, "canvas", 0, "Canvas");
ModPE.setItem (510, "compressedAluminum", 0, "Compressed Aluminum");
ModPE.setItem (511, "compressedBronze", 0, "Compressed Bronze");
ModPE.setItem (512, "compressedCopper", 0, "Compressed Copper");
ModPE.setItem (513, "compressedIron", 0, "Compressed Iron");
ModPE.setItem (514, "compressedSteel", 0, "Compressed Steel");
ModPE.setItem (515, "compressedTin", 0, "Compressed Tin");
ModPE.setItem (516, "dehydratedApple", 0, "Dehydrated Apple");
ModPE.setItem (517, "dehydratedCarrot", 0, "Dehydrated Carrot");
ModPE.setItem (518, "dehydratedMelon", 0, "Dehydrated Melon");
ModPE.setItem (519, "dehydratedPotato", 0, "Dehydrated Potato");
ModPE.setItem (520, "emptyLiquidCanister", 0, "Empty Liquid Canister", 1);
ModPE.setItem (521, "engine_tier1booster", 0, "Tier1 Booster Engine", 1);
ModPE.setItem (522, "engine_tier1engine", 0, "Tier1 Engine", 1);
ModPE.setItem (523, "frequencyModule", 0, "Frequency Module");
ModPE.setItem (524, "fuelCanisterPartial", 0, "Feul Canister Partial");
ModPE.setItem (525, "fuelCanisterPartial_1", 0, "Feul Canister Partial");
ModPE.setItem (526, "fuelCanisterPartial_2", 0, "Feul Canister Partial");
ModPE.setItem (527, "fuelCanisterPartial_3", 0, "Feul Canister Partial");
ModPE.setItem (528, "fuelCanisterPartial_4", 0, "Feul Canister Partial");
ModPE.setItem (529, "fuelCanisterPartial_5", 0, "Feul Canister Partial");
ModPE.setItem (530, "fuelCanisterPartial_6", 0, "Feul Canister Partial", 1);
ModPE.setItem (531, "heavyPlating", 0, "Heavy Plating");
ModPE.setItem (532, "infiniteBattery", 0, "Infinite Battery", 1);
ModPE.setItem (533, "ingotAluminum", 0, "Aluminum Ingot");
ModPE.setItem (534, "ingotCopper", 0, "Copper Ingot");
ModPE.setItem (535, "ingotTin", 0, "Tin Ingot");
ModPE.setItem (536, "key_T1", 0, "T1 key", 1);
ModPE.setItem (537, "noseCone", 0, "NoseCone");
ModPE.setItem (538, "oilCanisterPartial", 0, "Oil Canister Partial");

ModPE.setItem (539, "oilCanisterPartial_1", 0, "Oil Canister Partial");
ModPE.setItem (540, "oilCanisterPartial_2", 0, "Oil Canister Partial");
ModPE.setItem (541, "oilCanisterPartial_3", 0, "Oil Canister Partial");
ModPE.setItem (542, "oilCanisterPartial_4", 0, "Oil Canister Partial");
ModPE.setItem (543, "oilCanisterPartial_5", 0, "Oil Canister Partial");
ModPE.setItem (544, "oilCanisterPartial_6", 0, "Oil Canister Partial", 1);
ModPE.setItem (545, "oilExtractor_1", 0, "Oil Extractor");

ModPE.setItem (546, "oilExtractor_2", 0, "Oil Extractor");
ModPE.setItem (547, "oilExtractor_3", 0, "Oil Extractor");
ModPE.setItem (548, "oilExtractor_4", 0, "Oil Extractor");
ModPE.setItem (549, "oilExtractor_5", 0, "Oil Extractor");
ModPE.setItem (550, "oxygenCanisterInfinite", 0, "Oxygen Canister Infinite");
ModPE.setItem (551, "oxygenConcentrator", 0, "Oxygen Concentrator");
Item.defineArmor(552, "oxygenGear", 0, "Oxygen Gear", "mob/zombie.png", 3, 300, ArmorType.chestplate);

Item.defineArmor(553, "oxygenMask", 0, "Oxygen Mask", "mob/zombie.png", 3, 300, ArmorType.helmet);
ModPE.setItem (554, "oxygenTankHeavyFull", 0, "Oxygen Tank Heavy", 1);
ModPE.setItem (555, "oxygenTankLightFull", 0, "Oxygen Tank Light", 1);
ModPE.setItem (556, "oxygenTankMedFull", 0, "Oxygen Tank Medium", 1);
ModPE.setItem (557, "parachute_black", 0, "Black Parachute");
ModPE.setItem (558, "rawSilicon", 0, "Row Silicon");
ModPE.setItem (559, "rocketFins", 0, "Rocket Fins");
ModPE.setItem (560, "schematic_buggy", 0, "Buggy Schematic");
ModPE.setItem (561, "schematic_rocketT2", 0, "RocketT2 Schematic");
ModPE.setItem (562, "sensorGlasses", 0, "Sensor Glasses");
ModPE.setItem (563, "sensorLens", 0, "Sensor Lens");
ModPE.setItem (564, "solar_module", 0, "Solar Module");
ModPE.setItem (565, "solar_module_1", 0, "Solar Module");
ModPE.setItem (566, "standardWrench", 0, "Standard Wrench", 1);
ModPE.setItem (567, "steelPole", 0, "Steel Pole");
ModPE.setItem (568, "waferAdvanced", 0, "Advanced Wafer");
ModPE.setItem (569, "waferBasic", 0, "Basic Wafer");
//충전된 연료
Item.defineArmor(570, "oxygenTankHeavyFull", 0, "Oxygen Tank Heavy(Filled)", "mob/zombie.png", 5, 500, ArmorType.leggings);
Item.addShapedRecipe(554, 1, 0, ["aaa", "bbb", "ccc"], ["a", 35, 14, "b", 508, 0, "c", 514, 0]);
Item.defineArmor(571, "oxygenTankLightFull", 0, "Oxygen Tank Light(Filled)", "mob/zombie.png", 3, 100, ArmorType.leggings);
Item.addShapedRecipe(555, 1, 0, ["a  ", "b  ", "c  "], ["a", 35, 5, "b", 508, 0, "c", 512, 0]);
Item.defineArmor(572, "oxygenTankMedFull", 0, "Oxygen Tank Medium(Filled)", "mob/zombie.png", 4, 300, ArmorType.leggings);
Item.addShapedRecipe(556, 1, 0, ["aa ", "bb ", "cc "], ["a", 35, 1, "b", 508, 0, "c", 513, 0]);

ModPE.setItem (601, "rocket1", 0, "Tier 1 Rocket", 1);

Item.addShapedRecipe(545, 1, 0, ["a  ", " ab", "cbb"], ["a", 514, 1, "b", 511, 0, "c", 331, 0]);



Block.defineBlock(221, "Copper Ore", [["oreCopper", 0]], 1, false);
Block.defineBlock(222, "Aluminum Ore", [["oreAluminum", 0]], 1, false);
Block.defineBlock(223, "Tin Ore", [["oreTin", 0]], 1, false);
Block.defineBlock(224, "Silicon Ore", [["oreSilicon", 0]], 1, false);
Block.setDestroyTime (221, 5);
Block.setDestroyTime (222, 6);
Block.setDestroyTime (223, 7);
Block.setDestroyTime (224, 8);
Item.addFurnaceRecipe (221, 534, 0);
Item.addFurnaceRecipe (222, 533, 0);
Item.addFurnaceRecipe (223, 535, 0);
Block.defineBlock(225, "Coal Generator", [["machine_blank", 0], ["machine_blank", 0], ["machine_blank", 0], ["coalGenerator", 0], ["machine_blank", 0], ["machine_output", 0]]);
//아래 위 뒤 앞 오 왼
Block.setDestroyTime (225, 3);
Block.defineBlock(226, "Aluminum Wire", [["pipe_oxygen_black", 0]], 1, false);
Block.setDestroyTime (226, 2);
Block.setShape (226, 0, 0, 0, 1, 0.2, 1);
Item.addShapedRecipe(226, 1, 0, ["aaa", "bbb", "aaa"], ["a", 35, 0, "b", 533, 0]);
Item.addShapedRecipe(225, 1, 0, ["aaa", "bcb", "bdb"], ["a", 534, 0, "b", 265, 0, "c", 61, 0, "d", 226, 0]);
Block.defineBlock(227, "Circuit Fabricator", [["machine_blank", 0], ["machine_blank", 0], ["machine_blank", 0], ["circuit_fabricator", 0], ["machine_input", 0], ["machine_output", 0]]);
Block.setDestroyTime (227, 3);
Item.addShapedRecipe(227, 1, 0, ["aba", "cdc", "efe"], ["a", 533, 0, "b", 69, 0, "c", 1, 0, "d", 61, 0, "e", 226, 0, "f", 76, 0]);
Item.addShapedRecipe(227, 1, 0, ["aba", "cdc", "efe"], ["a", 533, 0, "b", 69, 0, "c", 1, 0, "d", 61, 0, "e", 226, 0, "f", 75, 0]);
Block.defineBlock(228, "Oil", [["oil_flow", 0]], 1, false);
Block.setRenderType(228, 4); 
Block.setRenderLayer(228, 1);
Block.setDestroyTime (228, 100);
Block.defineBlock(229, "Launch Pad", ["launch_pad", 0], 1, false);
Item.addShapedRecipe(229, 9, 0, ["aaa", "bbb", "   "], ["a", 265, 0, "b", 42, 0]);
Block.setDestroyTime (229, 2);
Block.setShape (229, 0, 0, 0, 1, 0.25, 1);
Block.defineBlock(230, "Launch Pad", ["launch_pad", 0], 1, false);
Block.setShape (230, 0, 0, 0, 1, 0.5, 1);
Block.setDestroyTime (230, 2);
Block.defineBlock(231, "Compressor", [["machine_blank", 0], ["machine_blank", 0], ["machine_side", 0], ["compressor", 0], ["machine_side", 0], ["machine_side", 0]]);
Block.setDestroyTime (231, 3);
Item.addShapedRecipe(231, 1, 0, ["aba", "aca", "ada"], ["a", 533, 0, "b", 145, 0, "c", 534, 0, "d", 569, 0]);
Block.defineBlock(232, "Nasa Workbench", [["machine_blank", 0], ["workbench_nasa_top", 0], ["workbench_nasa_side", 0], ["workbench_nasa_side", 0], ["workbench_nasa_side", 0], ["workbench_nasa_side", 0]]);
Block.setDestroyTime (232, 5);
Item.addShapedRecipe(232, 1, 0, ["aba", "cdc", "aea"], ["a", 514, 0, "b", 58, 0, "c", 69, 0, "d", 568, 0, "e", 76, 0]);
Block.defineBlock(233, "Aluminum Wire", [["pipe_oxygen_magenta", 0]], 1, false);
Block.setDestroyTime (233, 2);
Block.setShape (233, 0, 0, 0, 1, 0.2, 1);

//에너지 저장모듐 노가다

Block.defineBlock(234, "Energy Storage Module", [["machine_blank", 0], ["machine", 0], ["machine", 0], ["energyStorageModule_11", 0], ["machine", 0], ["machine", 0]]);
Block.setDestroyTime (234, 3);
Block.defineBlock(235, "Oxygen Pipe", [["pipe_oxygen_white", 0]], 1, false);
Item.addShapedRecipe(234, 1, 0, ["aaa", "bbb", "aaa"], ["a", 514, 0, "b", 503, 0]);
Block.setDestroyTime (235, 2);
Block.setShape (235, 0, 0, 0, 1, 0.2, 1);
Item.addShapedRecipe(235, 1, 0, ["aaa", "   ", "aaa"], ["a", 102, 0]);
Block.defineBlock(236, "Oxygen Pipe", [["pipe_oxygen_yellow", 0]], 1, false);
Block.setDestroyTime (236, 2);
Block.setShape (236, 0, 0, 0, 1, 0.2, 1);
Block.defineBlock(237, "Oxygen Collector", [["machine_blank", 0], ["machine_collector_fan", 0], ["machine", 0], ["machine_collector_fan", 0], ["machine", 0], ["machine", 0]]);
Block.setDestroyTime (237, 3);
Item.addShapedRecipe(237, 1, 0, ["aaa", "bcd", "efe"], ["a", 514, 0, "b", 501, 0, "c", 508, 0, "d", 502, 0, "e", 510, 0, "f", 551, 0]);
Block.defineBlock(238, "Oxygen Zipper", [["machine_blank", 0], ["machine", 0], ["machine", 0], ["machine", 0], ["machine_oxygen_input", 0], ["machine_oxygen_output", 0]]);
Block.setDestroyTime (238, 3);
Item.addShapedRecipe(238, 1, 0, ["aba", "bcb", "ada"], ["a", 514, 0, "b", 510, 0, "c", 551, 0, "d", 511, 0]);
Block.defineBlock(239, "Feul Loader", [["machine_blank", 0], ["machine", 0], ["machine", 0], ["machine_fuelloader", 0], ["machine_fuel_input", 0], ["machine", 0]]);
Block.setDestroyTime (239, 3);
Item.addShapedRecipe(239, 1, 0, ["aaa", "aba", "cdc"], ["a", 514, 0, "b", 510, 0, "c", 551, 0, "d", 511, 0]);
Block.defineBlock(211, "Refinery", [["machine_blank", 0], ["refinery_top", 0], ["machine", 0], ["refinery_front", 0], ["refinery_side", 0], ["machine", 0]]);
Block.setDestroyTime (211, 3);
Item.addShapedRecipe(211, 1, 0, [" a ", "bab", "cdc"], ["a", 507, 0, "b", 1, 0, "c", 514, 0, "d", 61, 0]);
Block.defineBlock(212, "Mars Cobblestone", [["cobblestone_mars", 0]]);
Block.setDestroyTime (212, 3);
Block.defineBlock(213, "Mars Block", [["top_mars", 0]]);
Block.setDestroyTime (213, 3);
Block.defineBlock(214, "Mars Iron", [["iron_mars", 0]]);
Block.setDestroyTime (214, 3);
Block.defineBlock(215, "Mars Block", [["bottom_mars", 0]]);
Block.setDestroyTime (215, 3);
//아이템 조합법
Item.addShapedRecipe(552, 1, 0, [" a ", "aba", "a a"], ["a", 235, 0, "b", 551, 0]);
Item.addShapedRecipe(503, 1, 0, [" a ", "aba", "aca"], ["a", 513, 0, "b", 331, 0, "c", 263, 0]);
Item.addShapedRecipe(508, 2, 0, ["a a", "a a", "aaa"], ["a", 535, 0]);
Item.addShapedRecipe(502, 1, 0, ["aaa", "b  ", "   "], ["a", 515, 0, "b", 514, 0]);
Item.addShapedRecipe(551, 1, 0, ["aba", "bcb", "ada"], ["a", 514, 0, "b", 515, 0, "c", 508, 0, "d", 502, 0]);
Item.addShapedRecipe(553, 1, 0, ["aaa", "aba", "aaa"], ["a", 102, 0, "b", 306, 0]);
Item.addShapedRecipe(502, 1, 0, [" a ", "aba", "a a"], ["a", 235, 0, "b", 553, 0]);
Item.addShapedRecipe(509, 1, 0, [" ab", "aaa", "ba "], ["a", 287, 0, "b", 280, 0]);
Item.addShapedRecipe(557, 1, 0, ["aaa", "b b", " b "], ["a", 509, 0, "b", 287, 0]);
Item.addShapedRecipe(501, 1, 0, ["a a", " b ", "aca"], ["a", 514, 0, "b", 569, 0, "c", 331, 0]);
Item.addShapedRecipe(522, 1, 0, [" ab", "cdc", "cec"], ["a", 259, 0, "b", 1, 0, "c", 531, 0, "d", 508, 0, "e", 502, 0]);
Item.addShapedRecipe(559, 1, 0, [" a ", "bab", "b b"], ["a", 514, 0, "b", 531, 0]);
Item.addShapedRecipe(537, 1, 0, [" a ", " b ", "b b"], ["a", 76, 0, "b", 531, 0]);
Item.addShapedRecipe(520, 1, 0, ["aba", "aca", "ada"], ["a", 514, 0, "b", 508, 0, "c", 510, 0, "d", 569, 0]);
Item.addShapedRecipe(507, 1, 0, ["a a", "a a", "aaa"], ["a", 534, 0]);

	createWindow ();
	for (var aa=501; aa <602; aa++){
		if (Item.isValidItem (aa)){
			Player.addItemCreativeInv(aa, 1, 0);
		}
	}for (var aa=221; aa <240; aa++){
		if (Item.isValidItem (aa)){
			Player.addItemCreativeInv(aa, 1, 0);
		}
	}
	Player.addItemCreativeInv(212, 1, 0);
	Player.addItemCreativeInv(213, 1, 0);
	Player.addItemCreativeInv(214, 1, 0);
	Player.addItemCreativeInv(215, 1, 0);
	dir = android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/games/com.mojang/minecraftWorlds/"+Level.getWorldDir()+"/Space_Mod";
	if (!new java.io.File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/games/com.mojang/minecraftWorlds/"+Level.getWorldDir()+"/Space_Mod").exists()){
		new java.io.File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/games/com.mojang/minecraftWorlds/"+Level.getWorldDir()+"/Space_Mod").mkdirs ();
		writeFile (dir + "/Electric.mn", "0,0,0,0,0,0,0,0,0");
		//석탄발전기, 회로 조립기, 압축기, 에너지저장모듐 정제소 적제소 연료주잊여부
		writeFile (dir + "/Oxygen.mn", "0,0");
		//산소수집기 산소압축기
	}
	var r1 = readFile (dir + "/Electric.mn").toString ().split (",");
	el.CoalG = parseInt (r1 [0]);
	el.CircuitF = parseInt (r1 [1]);
	el.Compressor = parseInt (r1 [2]);
	el.EnergyS = parseInt (r1 [3]);
	el.OxygenC = parseInt (r1 [4]);
el.OxygenZ = parseInt (r1 [5]);
el.Refinery = parseInt (r1 [6]);
el.FuelL = parseInt (r1 [7]);
el.okay = parseInt (r1 [8]);

var r2 = readFile (dir + "/Oxygen.mn").toString ().split (",");
ox.C = parseInt (r2 [0]);
ox.Z = parseInt (r2 [1]);
	//sdcard/games/com.mojang/minecraftWorlds/"+Level.getWorldDir()+"/level.dat
	
	
}
var pa = [274, 257, 285, 278];
var pa2 = [257, 285, 278];
//곡괭이
function destroyBlock (x, y, z, s){
var i = Player.getCarriedItem ();
if (getTile (x, y, z) == 225){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 225, 1, 0);
}if (getTile (x, y, z) == 226){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 226, 1, 0);
}if (getTile (x, y, z) == 227){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 227, 1, 0);
}if (getTile (x, y, z) == 228){
	preventDefault ();
}if (getTile (x, y, z) == 230){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 229, 1, 0);
}if (getTile (x, y, z) == 229){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 229, 1, 0);
}
if (getTile (x, y, z) == 233){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 226, 1, 0);
}if (getTile (x, y, z) == 231){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 231, 1, 0);
}if (getTile (x, y, z) == 232){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 232, 1, 0);
}if (getTile (x, y, z) == 234){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 234, 1, 0);
}if (getTile (x, y, z) == 235){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 235, 1, 0);
}if (getTile (x, y, z) == 236){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 235, 1, 0);
}if (getTile (x, y, z) == 237){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 237, 1, 0);
}if (getTile (x, y, z) == 238){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 238, 1, 0);
}if (getTile (x, y, z) == 239){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 239, 1, 0);
}if (getTile (x, y, z) == 211){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 211, 1, 0);
}if (getTile (x, y, z) == 212){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 212, 1, 0);
}
if (getTile (x, y, z) == 213){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 213, 1, 0);
}if (getTile (x, y, z) == 214){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 214, 1, 0);
}if (getTile (x, y, z) == 215){
	preventDefault ();
	setTile (x, y, z, 0);
	Level.dropItem (x, y, z, 0, 215, 1, 0);
}



	if (getTile (x, y, z) == 222){
		if (pa.indexOf (i) != -1){
			preventDefault ();
			setTile (x, y, z, 0);
			Level.dropItem (x, y, z, 0, 222, 1, 0);
		}if (pa.indexOf (i) == -1){
			preventDefault ();
			setTile (x, y, z, 0);
		}
	}if (getTile (x, y, z) == 221){
				if (pa2.indexOf (i) != -1){
			preventDefault ();
			setTile (x, y, z, 0);
			Level.dropItem (x, y, z, 0, 221, 1, 0);
		}if (pa2.indexOf (i) == -1){
			preventDefault ();
			setTile (x, y, z, 0);
		}
	}if (getTile (x, y, z) == 223){
		if (pa2.indexOf (i) != -1){
			preventDefault ();
			setTile (x, y, z, 0);
			Level.dropItem (x, y, z, 0, 223, 1, 0);
		}if (pa2.indexOf (i) == -1){
			preventDefault ();
			setTile (x, y, z, 0);
		}
	}if (getTile (x, y, z) == 224){
		if (pa2.indexOf (i) != -1){
			preventDefault ();
			setTile (x, y, z, 0);
			Level.dropItem (x, y, z, 0, 558, 1, 0);
		}if (pa2.indexOf (i) == -1){
			preventDefault ();
			setTile (x, y, z, 0);
		}
	}
}
var makingB = [225];
var needB = [227, 231, 234, 237, 238, 239, 211];
var needF = [el.CircuitF, el.Compressor];
function removeO (x, y, z){
	if (getTile (x+1, y, z) == 236){
		setTile (x+1, y, z, 235);
		removeO (x+1, y, z);
		return;
	}if (getTile (x-1, y, z) == 236){
		setTile (x-1, y, z, 235);
		removeO (x-1, y, z);
		return;
	}if (getTile (x, y, z+1) == 236){
		setTile (x, y, z+1, 235);
		removeO (x, y, z+1);
		return;
	}if (getTile (x, y, z-1) == 236){
		setTile (x, y, z-1, 235);
		removeO (x, y, z-1);
		return;
	}
}
function findO (x, y, z){
	//235 -> 236
	if (getTile (x+1, y, z) == 235){
		setTile (x+1, y, z, 236);
		findO (x+1, y, z);
		return;
	}if (getTile (x-1, y, z) == 235){
		setTile (x-1, y, z, 236);
		findO (x-1, y, z);
		return;
	}if (getTile (x, y, z+1) == 235){
		setTile (x, y, z+1, 236);
		findO (x, y, z+1);
		return;
	}if (getTile (x, y, z-1) == 235){
		setTile (x, y, z-1, 236);
		findO (x, y, z-1);
		return;
	}if (getTile (x+1, y, z) == 238){
		ox.send = true;
		toast ("산소를 보냅니다.");
		by = y, bx = x+1, bz = z;
	}if (getTile (x-1, y, z) == 238){
		ox.send = true;
		toast ("산소를 보냅니다.");
		by = y, bx = x-1, bz = z;
	}if (getTile (x, y, z+1) == 238){
		ox.send = true;
		toast ("산소를 보냅니다.");
		by = y, bx = x, bz = z+1;
	}if (getTile (x, y, z-1) == 238){
		ox.send = true;
		toast ("산소를 보냅니다.");
		by = y, bx = x, bz = z-1;
	}
}
function findF (type, x, y, z){
	
		if (getTile (x+1, y, z) == 226){
			setTile (x+1, y, z, 233);
			findF (type, x+1, y, z);
			return;
		}if (getTile (x-1, y, z) == 226){
			setTile (x-1, y, z, 233);
			findF (type, x-1, y, z);
			return;
		}if (getTile (x, y, z+1) == 226){
			setTile (x, y, z+1, 233);
			findF (type, x, y, z+1);
			return;
		}if (getTile (x, y, z-1) == 226){
			setTile (x, y, z-1, 233);
			findF (type, x, y, z-1);
			return;
		}if (needB.indexOf (getTile (x+1, y, z)) != -1){
			var tt = "";
			if (getTile (x+1, y, z) == 227){
				tt = "Circuit";
			}if (getTile (x+1, y, z) == 231){
				tt = "Compressor";
			}if (getTile (x+1, y, z) == 234){
				tt = "Energy";
			}if (getTile (x+1, y, z) == 237){
				tt = "OxygenC";
			}if (getTile (x+1, y, z) == 238){
				tt = "OxygenZ";
			}if (getTile (x+1, y, z) == 239){
				tt = "FuelL";
			}if (getTile (x+1, y, z) == 211){
				tt = "Refinery";
			}
			toast ("전송을 시작합니다");
			el.send = true;
			el.sender = type;
			el.target = tt;
			ay = y, ax = x+1, az = z;
		}if (needB.indexOf (getTile (x-1, y, z)) != -1){
			var tt = "";
			if (getTile (x-1, y, z) == 227){
				tt = "Circuit";
			}if (getTile (x-1, y, z) == 231){
				tt = "Compressor";
			}if (getTile (x-1, y, z) == 234){
				tt = "Energy";
			}if (getTile (x-1, y, z) == 237){
				tt = "OxygenC";
			}if (getTile (x-1, y, z) == 238){
				tt = "OxygenZ";
			}if (getTile (x-1, y, z) == 239){
				tt = "FuelL";
			}if (getTile (x-1, y, z) == 211){
				tt = "Refinery";
			}
			toast ("전송을 시작합니다");
			el.send = true;
			el.sender = type;
			el.target = tt;
			ay = y, ax = x-1, az = z;
		}if (needB.indexOf (getTile (x, y, z+1)) != -1){
			var tt = "";
			if (getTile (x, y, z+1) == 227){
				tt = "Circuit";
			}if (getTile (x, y, z+1) == 231){
				tt = "Compressor";
			}if (getTile (x, y, z+1) == 234){
				tt = "Energy";
			}if (getTile (x, y, z+1) == 237){
				tt = "OxygenC";
			}if (getTile (x, y, z+1) == 238){
				tt = "OxygenZ";
			}if (getTile (x, y, z+1) == 239){
				tt = "FuelL";
			}if (getTile (x, y, z+1) == 211){
				tt = "Refinery";
			}
			toast ("전송을 시작합니다");
			el.send = true;
			el.sender = type;
			el.target = tt;
			ay = y, ax = x, az = z+1;
		}if (needB.indexOf (getTile (x, y, z-1)) != -1){
			var tt = "";
			if (getTile (x, y, z-1) == 227){
				tt = "Circuit";
			}if (getTile (x, y, z-1) == 231){
				tt = "Compressor";
			}if (getTile (x, y, z-1) == 234){
				tt = "Energy";
			}if (getTile (x, y, z-1) == 237){
				tt = "OxygenC";
			}if (getTile (x, y, z-1) == 238){
				tt = "OxygenZ";
			}if (getTile (x, y, z-1) == 239){
				tt = "FuelL";
			}if (getTile (x, y, z-1) == 211){
				tt = "Refinery";
			}
			toast ("전송을 시작합니다");
			el.send = true;
			el.sender = type;
			el.target = tt;
			ay = y, ax = x, az = z-1;
		}
}
function removeF (x, y, z){
	if (getTile (x+1, y, z) == 233){
		setTile (x+1, y, z, 226);
		removeF (x+1, y, z);
		return;
	}if (getTile (x-1, y, z) == 233){
		setTile (x-1, y, z, 226);
		removeF (x-1, y, z);
		return;
	}if (getTile (x, y, z+1) == 233){
		setTile (x, y, z+1, 226);
		removeF (x, y, z+1);
		return;
	}if (getTile (x, y, z-1) == 233){
		setTile (x, y, z-1, 226);
		removeF (x, y, z-1);
		return;
	}
}
function CoalGenerator (x, y, z){
ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
var lay = new android.widget.LinearLayout (ctx);
lay.setOrientation (1);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기 량 : "+el.CoalG + "/500");
lay.addView (hT);
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (263, 0) > 0){
	rmi (263, 1);
	progDialog ("석탄 발전 중입니다.", "전류", "석탄 발전이 끝났습니다.");
	el.CoalG += 100;
	hT.setText ("현재 있는 전기 량 : "+el.CoalG + "/500");
}else {
	toast ("석탄이 부족합니다")
}
}
}));
btn1.setText("발전기 가동 (1개 당 100)");
lay.addView(btn1); 
var btn2 = new android.widget.Button(ctx); 
btn2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	el.send = false;
	toast ("전기 전송이 중단되었습니다.");
	removeF (x, y, z);
	return;
}
if (el.CoalG == 0){
	toast ("전기가 없습니다.");
	return;
}
findF ("Coal", x, y, z);

}
}));
btn2.setText("전기 보내기/멈추기");
lay.addView(btn2); 
new android.app.AlertDialog.Builder(ctx)
.setTitle("석탄 발전기")
.setView(lay)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}
function CircuitFabricator (){
ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
var lay = new android.widget.LinearLayout (ctx);
lay.setOrientation (1);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기 량 : "+el.CircuitF + "/500");
lay.addView (hT);

var t1 = new android.widget.TextView (ctx);
t1.setText ("기초 웨이퍼 : 다이아몬드 + 천연 실리콘 × 2 + 레드스톤 + 레드스톤 토치 (전기 100 소모)");
lay.addView (t1); 
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (264, 0) > 0 && gia (331, 0) > 0 && gia (558, 0) > 1 && gia (76, 0)> 0 && el.CircuitF > 99){
	rmi (264, 1);
	rmi (331, 1);
	rmi (558, 2);
	rmi (76, 1);
	progDialog ("기초 웨이퍼 제작 중입니다.", "생산", 569, 1, 0);
	el.CircuitF -= 100;
	hT.setText ("현재 있는 전기 량 : "+el.CircuitF + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn1.setText("기초 웨이퍼 제작");
lay.addView(btn1); 
var t2 = new android.widget.TextView (ctx);
t2.setText ("기초 웨이퍼 : 다이아몬드 + 천연 실리콘 × 2 + 레드스톤 + 레드스톤 리피터 (전기 150 소모)");
lay.addView (t2); 
var btn2 = new android.widget.Button(ctx); 
btn2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (264, 0) > 0 && gia (331, 0) > 0 && gia (558, 0) > 1 && gia (356, 0)> 0 && el.CircuitF > 149){
	rmi (264, 1);
	rmi (331, 1);
	rmi (558, 2);
	rmi (356, 1);
	progDialog ("고급 웨이퍼 제작 중입니다.", "제작", 568, 1, 0);
	el.CircuitF -= 150;
	hT.setText ("현재 있는 전기 량 : "+el.CircuitF + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn2.setText("고급 웨이퍼 제작");
lay.addView(btn2); 
new android.app.AlertDialog.Builder(ctx)
.setTitle("회로 조립기")
.setView(lay)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}
function Compressor (){
	ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
	var scr = new android.widget.ScrollView (ctx);
var lay = new android.widget.LinearLayout (ctx);
lay.setOrientation (1);
scr.addView (lay);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기 량 : " + el.Compressor + "/500");
lay.addView (hT);

var t1 = new android.widget.TextView (ctx);
t1.setText ("압축 철 : 철 주괴 (전기 100 소모)");
lay.addView (t1); 
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (265, 0) > 0 && el.Compressor > 99){
	rmi (265, 1);
	progDialog ("철 압축중...", "생산", 513, 1, 0);
	el.Compressor -= 100;
	hT.setText ("현재 있는 전기 량 : "+el.Compressor + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn1.setText("철 주괴 압축");
lay.addView(btn1); 
var t2 = new android.widget.TextView (ctx);
t2.setText ("압축 구리 : 구리 (전기 100 소모)");
lay.addView (t2); 
var btn2 = new android.widget.Button(ctx); 
btn2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (534, 0) > 0 && el.Compressor > 99){
	rmi (534, 1);
	progDialog ("구리 압축중...", "생산", 512, 1, 0);
	el.Compressor -= 100;
	hT.setText ("현재 있는 전기 량 : "+el.Compressor + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn2.setText("구리 압축");
lay.addView(btn2); 
var t3 = new android.widget.TextView (ctx);
t3.setText ("압축 알루미늄 : 알루미늄 (전기 100 소모)");
lay.addView (t3); 
var btn3 = new android.widget.Button(ctx); 
btn3.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (533, 0) > 0 && el.Compressor > 99){
	rmi (533, 1);
	progDialog ("알루미늄 압축중...", "생산", 510, 1, 0);
	el.Compressor -= 100;
	hT.setText ("현재 있는 전기 량 : "+el.Compressor + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn3.setText("알루미늄 압축");
lay.addView(btn3); 
var t4 = new android.widget.TextView (ctx);
t4.setText ("압축 주석 : 주석 (전기 100 소모)");
lay.addView (t4); 
var btn4 = new android.widget.Button(ctx); 
btn4.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (535, 0) > 0 && el.Compressor > 99){
	rmi (535, 1);
	progDialog ("주석 압축중...", "생산", 515, 1, 0);
	el.Compressor -= 100;
	hT.setText ("현재 있는 전기 량 : "+el.Compressor + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn4.setText("주석 압축");
lay.addView(btn4); 
var t5 = new android.widget.TextView (ctx);
t5.setText ("압축 강철 : 압축 철 + 석탄 x 2 (전기 150 소모)");
lay.addView (t5); 
var btn5 = new android.widget.Button(ctx); 
btn5.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (513, 0) > 0 && gia (263, 0) > 1 && el.Compressor > 149){
	rmi (513, 1);
	rmi (263, 2);
	progDialog ("압축 강철 제조중...", "생산", 514, 1, 0);
	el.Compressor -= 150;
	hT.setText ("현재 있는 전기 량 : "+el.Compressor + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn5.setText("압축 강철 제조");
lay.addView(btn5); 
var t6 = new android.widget.TextView (ctx);
t6.setText ("압축 청동 : 압축 구리 + 압축 주석 (전기 150 소모)");
lay.addView (t6); 
var btn6 = new android.widget.Button(ctx); 
btn6.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (512, 0) > 0 && gia (515, 0) > 0 && el.Compressor > 149){
	rmi (512, 1);
	rmi (515, 1);
	progDialog ("압축 강철 제조중...", "생산", 511, 1, 0);
	el.Compressor -= 150;
	hT.setText ("현재 있는 전기 량 : "+el.Compressor + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn6.setText("압축 청동 제조");
lay.addView(btn6); 
var t7 = new android.widget.TextView (ctx);
t7.setText ("강화 플레이트 : 압축 강철 × 2 + 압축 알루미늄 × 2 + 압축 청동 × 2 (전기 200 소모)");
lay.addView (t7); 
var btn7 = new android.widget.Button(ctx); 
btn7.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (510, 0) > 1 && gia (511, 0) > 1 && gia (514, 0) > 1 && el.Compressor > 199){
	rmi (510, 2);
	rmi (511, 2);
	rmi (514, 2);
	progDialog ("강화 플레이트 제조중...", "생산", 531, 1, 0);
	el.Compressor -= 200;
	hT.setText ("현재 있는 전기 량 : "+el.Compressor + "/500");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn7.setText("강화 플레이트 제조");
lay.addView(btn7); 
new android.app.AlertDialog.Builder(ctx)
.setTitle("압축기")
.setView(scr)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}
function EnergyStorageModule (x, y, z){
	ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
var lay = new android.widget.LinearLayout (ctx);
lay.setOrientation (1);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기 량 : "+el.EnergyS + "/5000");
lay.addView (hT);
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (gia (503, 0) > 0){
	rmi (503, 1);
	progDialog ("에너지 저장 모듈 충전중", "전류", "에너지 저장 모듈을 정상적으로 충전했습니다.");
	el.EnergyS += 500;
	hT.setText ("현재 있는 전기 량 : "+el.EnergyS + "/5000");
}else {
	toast ("재료가 부족하거나 전기가 없습니다.");
}
}
}));
btn1.setText("배터리로 모듈 충전 (500)");
lay.addView(btn1); 
var btn2 = new android.widget.Button(ctx); 
btn2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	el.send = false;
	toast ("전기 전송이 중단되었습니다.");
	removeF (x, y, z);
	return;
}
if (el.EnergyS == 0){
	toast ("전기가 없습니다.");
	return;
}
findF ("Energy", x, y, z);

}
}));
btn2.setText("전기 보내기/멈추기");
lay.addView(btn2); 
new android.app.AlertDialog.Builder(ctx)
.setTitle("에너지 저장 모듈")
.setView(lay)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}
function OxygenCollector (x, y, z){
	ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
var lay = new android.widget.LinearLayout (ctx);
lay.setOrientation (1);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기량 : "+el.OxygenC + "/300 \n현재 있는 산소량 : "+ox.C+"/300");
lay.addView (hT);
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (ox.send){
	toast ("산소를 보내는 중입니다.");
	return;
}
if (ox.receive){
	toast ("산소를 수집하는 중입니다.");
	return;
}
if (el.OxygenC > 0){
	ox.receive = true;
}else {
	toast ("전기가 없습니다.");
}
}
}));
btn1.setText("산소 수집/중단");
lay.addView(btn1); 
var btn2 = new android.widget.Button(ctx); 
btn2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (ox.send){
	toast ("산소를 보내는 중입니다.");
	return;
}
if (ox.receive){
	toast ("산소를 수집하는 중입니다.");
	return;
}
if (ox.C == 0){
	toast ("산소가 없습니다.");
	return;
}
findO (x, y, z);

}
}));
btn2.setText("산소 보내기/멈추기");
lay.addView(btn2); 
new android.app.AlertDialog.Builder(ctx)
.setTitle("산소 수집기")
.setView(lay)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}
function OxygenZipper (){
	ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
	var scr = new android.widget.ScrollView (ctx);
	
var lay = new android.widget.LinearLayout (ctx);
scr.addView (lay);
lay.setOrientation (1);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기량 : "+el.OxygenZ + "/300\n현재 있는 산소량 : "+ox.Z+"/300");
lay.addView (hT);

var t1 = new android.widget.TextView (ctx);
t1.setText ("소형 산소 탱크 충전 (전기 100 & 산소 100 소모)");
lay.addView (t1); 
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (ox.send){
	toast ("산소를 보내는 중입니다.");
	return;
}
if (ox.receive){
	toast ("산소를 수집하는 중입니다.");
	return;
}
if (ox.Z == 0){
	toast ("산소가 없습니다.");
	return;
}
//555 556 554 571 572 570
if (gia (555, 0) > 0 && el.OxygenZ > 99 && ox.Z > 99){
	rmi (555, 1);
	progDialog ("소형 산소 탱크 충전 중입니다.", "생산", 571, 1, 0);
	el.OxygenZ -= 100;
	ox.Z -= 100;
	hT.setText ("현재 있는 전기량 : "+el.OxygenZ + "/300\n현재 있는 산소량 : "+ox.Z+"/300");
}else {
	toast ("산소, 전기가 부족하거나 충전시킬 물품이 없습니다.");
}
}
}));
btn1.setText("소형 산소 탱크 충전");
lay.addView(btn1); 
var t2 = new android.widget.TextView (ctx);
t2.setText ("중형 산소 탱크 충전 (전기 150 & 산소 150 소모)");
lay.addView (t2); 
var btn2 = new android.widget.Button(ctx); 
btn2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (ox.send){
	toast ("산소를 보내는 중입니다.");
	return;
}
if (ox.receive){
	toast ("산소를 수집하는 중입니다.");
	return;
}
if (ox.Z == 0){
	toast ("산소가 없습니다.");
	return;
}
//555 556 554 571 572 570
if (gia (556, 0) > 0 && el.OxygenZ > 149 && ox.Z > 149){
	rmi (556, 1);
	progDialog ("중형 산소 탱크 충전 중입니다.", "생산", 572, 1, 0);
	el.OxygenZ -= 150;
	ox.Z -= 150;
	hT.setText ("현재 있는 전기량 : "+el.OxygenZ + "/300\n현재 있는 산소량 : "+ox.Z+"/300");
}else {
	toast ("산소, 전기가 부족하거나 충전시킬 물품이 없습니다.");
}
}
}));
btn2.setText("중형 산소 탱크 충전");
lay.addView(btn2); 
var t3 = new android.widget.TextView (ctx);
t3.setText ("대형 산소 탱크 충전 (전기 200 & 산소 200 소모)");
lay.addView (t3); 
var btn3 = new android.widget.Button(ctx); 
btn3.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (ox.send){
	toast ("산소를 보내는 중입니다.");
	return;
}
if (ox.receive){
	toast ("산소를 수집하는 중입니다.");
	return;
}
if (ox.Z == 0){
	toast ("산소가 없습니다.");
	return;
}
//555 556 554 571 572 570
if (gia (554, 0) > 0 && el.OxygenZ > 199 && ox.Z > 199){
	rmi (554, 1);
	progDialog ("대형 산소 탱크 충전 중입니다.", "생산", 570, 1, 0);
	el.OxygenZ -= 200;
	ox.Z -= 200;
	hT.setText ("현재 있는 전기량 : "+el.OxygenZ + "/300\n현재 있는 산소량 : "+ox.Z+"/300");
}else {
	toast ("산소, 전기가 부족하거나 충전시킬 물품이 없습니다.");
}
}
}));
btn3.setText("대형 산소 탱크 충전");
lay.addView(btn3); 

new android.app.AlertDialog.Builder(ctx)
.setTitle("산소 압축기")
.setView(scr)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}
function FuelLoader (){
	var aa;
	if (el.okay == 0){
		aa = "X";
	}
	if (el.okay == 1){
		aa = "O";
	}
	ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
	var scr = new android.widget.ScrollView (ctx);
	
var lay = new android.widget.LinearLayout (ctx);
scr.addView (lay);
lay.setOrientation (1);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기량 : "+el.FuelL + "/500 \n연료 주입 : "+aa);
lay.addView (hT);

var t1 = new android.widget.TextView (ctx);
t1.setText ("연료 주입 (전기 500 소모)");
lay.addView (t1); 
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (el.FuelL == 0){
	toast ("전기가 없습니다.");
	return;
}
if (el.okay == 1){
	toast ("이미 연료를 넣었습니다.");
	return;
}
//555 556 554 571 572 570
if (gia (530, 0) > 0 && el.FuelL > 499){
	rmi (530, 1);
	progDialog ("연료 주입 중입니다.", "전류", "연료 주입 완료", 1, 0);
	el.fuelL -= 500;
	hT.setText ("현재 있는 전기량 : "+el.FuelL + "/500 \n연료 주입 : "+aa);
	el.okay = 1;
}else {
	toast ("전기가 부족하거나 연료 통이 없습니다.");
}
}
}));
btn1.setText("연료 주입");
lay.addView(btn1); 

new android.app.AlertDialog.Builder(ctx)
.setTitle("연료 주입기")
.setView(scr)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}
function Refinery (){
	ctx.runOnUiThread(new java.lang.Runnable({
run: function(){
try{
	var scr = new android.widget.ScrollView (ctx);
	
var lay = new android.widget.LinearLayout (ctx);
scr.addView (lay);
lay.setOrientation (1);
var hT = new android.widget.TextView (ctx);
hT.setText ("현재 있는 전기량 : "+el.Refinery+"/500");
lay.addView (hT);

var t1 = new android.widget.TextView (ctx);
t1.setText ("기름 정제 (전기 500 소모) (빈 깡통 & 가득 찬 기름통 필요)");
lay.addView (t1); 
var btn1 = new android.widget.Button(ctx); 
btn1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (el.send){
	toast ("전기를 보내는 중입니다.");
	return;
}
if (el.Refinery == 0){
	toast ("전기가 없습니다.");
	return;
}
//555 556 554 571 572 570
if (gia (544, 0) > 0 && gia (520, 0) > 0 && el.Refinery > 499){
	rmi (544, 1);
	rmi (520, 1);
	progDialog ("기름 정제 중입니다.", "생산", 530, 1, 0);
	el.Refinery -= 500;
	hT.setText ("현재 있는 전기량 : "+el.Refinery + "/500");
	
}else {
	toast ("전기가 부족하거나 기름 통이 없습니다.");
}
}
}));
btn1.setText("기름 정제");
lay.addView(btn1); 

new android.app.AlertDialog.Builder(ctx)
.setTitle("정제소")
.setView(scr)


.setPositiveButton("닫기",new android.content.DialogInterface.OnClickListener({onClick:function(){


}}))

.create().show();


}catch(e){
clientMessage(e);
}
}}));
}



function procCmd (c){
	for (var a=501; a < 570; a++){
	//	addItemInventory (a, 1, 0);
	}
	if (c == "광물"){
		for (var nu=0; nu <100; nu++){
			var xc=Math.floor(Player.getX()/32)*32;
var zc=Math.floor(Player.getZ()/32)*32;
for(var x=-32;x<=32;x+=32)
{
for(var z=-32;z<=32;z+=32)
{
if(Level.getData(xc+x,0,zc+z)==0&&Level.getTile(xc+x,0,zc+z)==7)
{
var num=Math.floor(Math.random()*11+5);//최소 5개 최대 15개의 광맥 생성
while(num>0)
{
num--;
var OreR = Math.floor (Math.random ()*5+1);
if (genN == 1){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*60 + 10);//높이제한
var ranz=Math.floor(Math.random()*32);


jenore(xc+x+ranx, rany, zc+z+ranz, 221, 0, 4, 8, 1, 4, 2);
}if (genN == 2){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*50 + 20);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 222, 0, 5, 8, 1, 4, 2);
}if (genN == 3){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*30);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 223, 0, 4, 6, 1, 4, 2);
}if (genN == 4){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*20);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 224, 0, 3, 5, 1, 4, 2);
}if (genN == 5){
	genN = 1;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*60);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 228, 0, 7, 5, 1, 4, 2);
}
//요개핵심
// jenore(x,y,z,블럭id,damage,광맥최대길이,광물 뭉침정도,광맥최소길이,광물 뭉침도 최소양,광맥크기);
}
Level.setTile(xc+x,0,zc+z,7,1);
}
}
}
		}
		toast ("광물 생성 완료");
	}
}
const effect = {포화:MobEffect.saturation, 흡수:MobEffect.absorption, 체력신장:MobEffect.healthBoost, 위더:MobEffect.wither, 독:MobEffect.poison, 나약함:MobEffect.weakness, 허기:MobEffect.hunger, 야간투시:MobEffect.nightVision, 실명:MobEffect.blindness, 투명화:MobEffect.invisibility, 수중호흡:MobEffect.waterBreathing, 화염저항:MobEffect.fireResistance, 저항:MobEffect.damageResistance, 재생:MobEffect.regeneration, 멀미:MobEffect.confusion, 점프강화:MobEffect.jump, 즉시데미지:MobEffect.harm, 즉시회복:MobEffect.heal, 힘:MobEffect.damageBoost, 피로:MobEffect.digSlowdown,
성급함:MobEffect.digSpeed,
구속:MobEffect.movementSlowdown, 신속:MobEffect.movementSpeed};

// Entity.addEffect(ent, effect.신속, time, level, false, true);
function useItem (x, y, z, i, b){
	
	var g = getTile;






	if (b == 230 && i == 601){
		if (el.okay == 0){
			toast ("연료를 주입해주세요.");
			return;
		}
		Entity.setRenderType(Player.getEntity (), steve.renderType );
Entity.setMobSkin (Player.getEntity (), "mob/rocket_S2.png");
CountDown = 207;
Entity.addEffect (Player.getEntity (), effect.구속, 200, 99);
lx = x;
ly = y;
lz = z;
Entity.setPosition (getPlayerEnt (), x, y+2, z);
		
	}
	if (b == 232){
		preventDefault ();
		NasaWorkBench ();
	}
	if (b == 239){
		preventDefault ();
		FuelLoader ();
	}
	if (b == 211){
		Refinery ();
		preventDefault ();
	}
	if (i == 239){
		//229
		if (g (x+1, y+1, z) == 229){
			setTile (x+1, y+1, z, 230);
		}if (g (x-1, y+1, z) == 229){
			setTile (x-1, y+1, z, 230);
		}if (g (x, y+1, z+1) == 229){
			setTile (x, y+1, z+1, 230);
		}if (g (x, y+1, z-1) == 229){
			setTile (x, y+1, z-1, 230);
		}
	}
	if (i == 545 && b == 228){
		//520 538
		if (gia (520, 0) > 0){
			rmi (520, 1);
			addItemInventory (538, 1);
			return;
		}if (gia (538, 0) > 0){
			rmi (538, 1);
			addItemInventory (539, 1);
			return;
		}if (gia (539, 0) > 0){
			rmi (539, 1);
			addItemInventory (540, 1);
			return;
		}if (gia (540, 0) > 0){
			rmi (540, 1);
			addItemInventory (541, 1);
			return;
		}if (gia (541, 0) > 0){
			rmi (541, 1);
			addItemInventory (542, 1);
			return;
		}if (gia (542, 0) > 0){
			rmi (542, 1);
			addItemInventory (543, 1);
			return;
		}if (gia (543, 0) > 0){
			rmi (543, 1);
			addItemInventory (544, 1);
			return;
		}
	}
	if (i == 229 && g (x+1, y+1, z) == 229 && g (x-1, y+1, z) == 229 && g (x, y+1, z+1) == 229 && g (x, y+1, z-1) == 229 && g (x+1, y+1, z+1) == 229 && g (x+1, y+1, z+1) == 229 && g (x-1, y+1, z+1) == 229 && g (x-1, y+1, z-1) == 229){
		preventDefault ();
		Entity.setCarriedItem (getPlayerEnt (), 0, 1, 1, 0);
		setTile (x, y+1, z, 230);
	}
	if (b == 225){
		preventDefault ();
		CoalGenerator (x, y, z);
	}if (b == 227){
		preventDefault ();
		CircuitFabricator ();
	}if (b == 231){
		preventDefault ();
		Compressor ();
	}if (b == 234){
		preventDefault ();
		EnergyStorageModule (x, y, z);
	}if (b == 237){
		preventDefault ();
		OxygenCollector (x, y, z);
	}if (b == 238){
		preventDefault ();
		OxygenZipper ();
	}
}
var genN = 1;
var lx, ly, lz;
function modTick()
{
	if (makeCool > 0){
		makeCool --;
	}if (makeCool == 0){
		makeCool = 60 * 20;
		for (var nu=0; nu <100; nu++){
			var xc=Math.floor(Player.getX()/32)*32;
var zc=Math.floor(Player.getZ()/32)*32;
for(var x=-32;x<=32;x+=32)
{
for(var z=-32;z<=32;z+=32)
{
if(Level.getData(xc+x,0,zc+z)==0&&Level.getTile(xc+x,0,zc+z)==7)
{
var num=Math.floor(Math.random()*11+5);//최소 5개 최대 15개의 광맥 생성
while(num>0)
{
num--;
var OreR = Math.floor (Math.random ()*5+1);
if (genN == 1){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*60 + 10);//높이제한
var ranz=Math.floor(Math.random()*32);


jenore(xc+x+ranx, rany, zc+z+ranz, 221, 0, 4, 8, 1, 4, 2);
}if (genN == 2){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*50 + 20);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 222, 0, 5, 8, 1, 4, 2);
}if (genN == 3){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*30);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 223, 0, 4, 6, 1, 4, 2);
}if (genN == 4){
	genN ++;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*20);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 224, 0, 3, 5, 1, 4, 2);
}if (genN == 5){
	genN = 1;
var ranx=Math.floor(Math.random()*32);
var rany=Math.floor(Math.random()*60);//높이제한
var ranz=Math.floor(Math.random()*32);

jenore(xc+x+ranx, rany, zc+z+ranz, 228, 0, 7, 5, 1, 4, 2);
}
//요개핵심
// jenore(x,y,z,블럭id,damage,광맥최대길이,광물 뭉침정도,광맥최소길이,광물 뭉침도 최소양,광맥크기);
}
Level.setTile(xc+x,0,zc+z,7,1);
}
}
}
		}
		toast ("광물 생성 완료");
	}
	if (CountDown > 0){
		CountDown --;
		if (CountDown % 20 == 0 && CountDown > 90){
			toast (Math.floor (CountDown / 20) - 5 + "");
		}
	}if (CountDown == 1){
			toast ("Go");
			setVelY (getPlayerEnt (), 8);
			Mars = 80;
		}
	if (Mars > 0){
		Mars --;
	}
	if (Mars == 1){
		Entity.addEffect (Player.getEntity (), effect.저항, 60, 4, false, true);
		setVelY (getPlayerEnt (), -10);
		Block.defineBlock(2, "Mars Block", ["top_mars",0],0);
Block.defineBlock(3, "Mars Block", ["top_mars",0],0);
Block.defineBlock(1, "Mars Block", ["top_mars",0],0);
Block.defineBlock(4, "Mars Block", ["top_mars",0],0);
Block.defineBlock(161, "Mars Block", ["top_mars",0],0);
Block.defineBlock(18, "Mars Block", ["top_mars",0],0);
Block.defineBlock(17, "Mars Block", ["cobblestone_mars",0],0);
Block.defineBlock(162, "Mars Block", ["cobblestone_mars",0],0);
Block.defineBlock(12, "Mars Block", ["cobblestone_mars",0],0);
Block.defineBlock(60, "Mars Block", ["cobblestone_mars",0],0);
ModPE.setItem(260,"diamond",0,"Diamond");
Block.defineBlock(243, "Mars Block", ["cobblestone_mars",0],0);
Block.defineBlock(110, "Mars Block", ["cobblestone_mars",0],0);
toast ("나갔다 들어와주세요");

	}
	if (saveC > 0){
		saveC --;
	}if (saveC == 0){
		saveC = 400;
		writeFile (dir + "/Electric.mn", el.CoalG + "," +el.CircuitF + "," + el.Compressor + "," + el.EnergyS + "," + el.OxygenC + "," + el.OxygenZ + "," + el.Refinery + "," + el.FuelL + "," + el.okay)
		
writeFile (dir + "/Oxygen.mn", ox.C + ","+ox.Z);
var r2 = readFile (dir + "/Oxygen.mn").toString ().split (",");

		clientMessage ("저장완료");
		
	}
	if (ox.send){
		if (ox.C > 0){
			ox.C --;
			ox.Z ++;
		}if (ox.C == 0 || ox.Z > 300){
			ox.send = false;
			removeO (bx, by, bz);
			toast ("작동 종료");
		}
	}
	if (el.send){
		if (el.sender == "Coal"){
			
			if (el.CoalG > 0){
				el.CoalG --;
			}
			
			if (el.target == "Circuit"){
				
				el.CircuitF ++;
				if (el.CoalG == 0 || el.CircuitF > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "Compressor"){
				
				el.Compressor ++;
				if (el.CoalG == 0 || el.Compressor > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "Energy"){
				
				el.EnergyS ++;
				if (el.CoalG == 0 || el.EnergyS > 4999){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "OxygenC"){
				
				el.OxygenC ++;
				if (el.CoalG == 0 || el.OxygenC > 299){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "OxygenZ"){
				
				el.OxygenZ ++;
				if (el.CoalG == 0 || el.EnergyZ > 299){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "FuelL"){
				
				el.FuelL ++;
				if (el.CoalG == 0 || el.FuelL > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "Refinery"){
				
				el.Refinery ++;
				if (el.CoalG == 0 || el.Refinery > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}
			
		}if (el.sender == "Energy"){
			
			if (el.EnergyS > 0){
				el.EnergyS --;
			}
			
			if (el.target == "Circuit"){
				
				el.CircuitF ++;
				if (el.EnergyS == 0 || el.CircuitF > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "Compressor"){
				
				el.Compressor ++;
				if (el.EnergyS == 0 || el.Compressor > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "OxygenC"){
				
				el.OxygenC ++;
				if (el.EnergyS == 0 || el.OxygenC > 299){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "OxygenZ"){
				
				el.OxygenZ ++;
				if (el.EnergyS == 0 || el.OxygenZ > 299){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "FuelL"){
				
				el.FuelL ++;
				if (el.EnergyS == 0 || el.FuelL > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}if (el.target == "Refinery"){
				
				el.Refinery ++;
				if (el.EnergyS == 0 || el.Refinery > 499){
					el.send = false;
					toast ("작동 종료");
					removeF (ax, ay, az);
				}
			}
			
			
			
		}
	}
	if (el.CoalG > 500){
		el.CoalG = 500;
	}if (el.CircuitF > 500){
		el.CircuitF = 500;
	}if (el.Compressor > 500){
		el.Compressor = 500;
	}if (el.EnergyS > 5000){
		el.EnergyS = 5000;
	}if (el.OxygenC > 300){
		el.OxygenC = 300;
	}if (el.OxygenZ > 300){
		el.OxygenZ = 300;
	}if (ox.C > 300){
		ox.C = 300;
	}if (ox.Z > 300){
		ox.Z = 300;
	}if (el.FuelL > 500){
		el.FuelL = 500;
	}if (el.Refinery > 500){
		el.Refinery = 500;
	}
	if (ox.receive){
		if (el.OxygenC > 0){
			el.OxygenC --;
			ox.C ++;
		}
		if (el.OxygenC == 0 || ox.C == 300){
			ox.receive = false;
			toast ("산소 수집 종료");
		}
	}

}
function jenore(x,y,z,a,b,c,d,mc,md,s)
{
c=c-mc;
d=d-md;
if(Level.getTile(x,y,z)==1)
{
Level.setTile(x,y,z,a,b);
}
var ran1=mc+Math.floor(c*Math.random());
var w1=0;
while(w1<=ran1)
{
w1++
var ran2=md+Math.floor(Math.random()*d);
var w2=0;
while(w2<=ran2)
{
var xx=x+Math.floor(Math.random()*s-Math.floor(s/2));
var yy=y+Math.floor(Math.random()*s-Math.floor(s/2));
var zz=z+Math.floor(Math.random()*s-Math.floor(s/2));
if(Level.getTile(xx,yy,zz)==1)
{
Level.setTile(xx,yy,zz,a,b);
}
if(w2==ran2)
{
x=xx;
y=yy;
z=zz;
}
w2++;
}
}
}


function Dialog(title, type, info, addi, adda, addd){ 
ctx.runOnUiThread( new java.lang.Runnable({
run: function(){
try{
	if (type == "생산"){
new android.app.AlertDialog.Builder(ctx)

.setTitle(title + "")
.setMessage(info + "")
.setPositiveButton("확인",new android.content.DialogInterface.OnClickListener({onClick:function(){
addItemInventory (addi, adda, addd);
}}))
.create().show();
}if (type == "전류"){
new android.app.AlertDialog.Builder(ctx)

.setTitle(title + "")
.setMessage(info + "")
.setPositiveButton("확인",new android.content.DialogInterface.OnClickListener({onClick:function(){

}}))
.create().show();
}
}catch(e){
clientMessage(e);
}
}}));
}
function progDialog(title, type, id, amo, dam){
	var dialog = new android.app.ProgressDialog(ctx, 0);
	dialog.setProgressStyle(1);
	dialog.setMax(100);
	dialog.setCancelable(false);
	
		dialog.setTitle(title + "");
		dialog.show();
		new java.lang.Thread(new java.lang.Runnable({run: function(){
			for(var i=0;i<=100;i++){
				dialog.setProgress(i);
				java.lang.Thread.sleep(50);
			}
			dialog.dismiss();
			if (type == "생산"){
			Dialog("완성", type, "Id : "+id+"/Amo : "+amo+"", id, amo, dam);
			}if (type == "전류"){
			Dialog("완료", type, id);
			}
		}})).start();
	
}
function gia(itemId,itemData)
{/*
	if (Level.getGameMode () == 1){
		return 0;
	}*/
var amount = 0;

for(var i=9; i<=44; i++){
if(Player.getInventorySlot(i) == itemId&&Player.getInventorySlotData(i) == itemData){
amount += Player.getInventorySlotCount(i);
}
}return amount;
}
function rmi(sid, snum){
    for(var i = 9; i<44; i++) {
      if(Player.getInventorySlot(i) == sid) {
        var haveC= Player.getInventorySlotCount(i);

        if(haveC == snum) {
         Player.clearInventorySlot(i);
          return;
        }

        if(haveC > snum) {
          if(haveC >= 64) {
            Player.clearInventorySlot(i);
            haveC-=snum;
            
            if(haveC!=0) {addItemInventory(sid, haveC, 0);
        
            }
            return;
          }
          if(haveC < 64) {
            addItemInventory(sid, -snum, 0);
            
            return;
          }
       }
    }
  }
  
}
function toast(message){

ctx.runOnUiThread(new java.lang.Runnable({run: function(){

var text = new android.widget.TextView(ctx);
text.setText(message);
text.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 20);
text.setTextColor (android.graphics.Color.parseColor ("#CDDC39"));
var toast = new android.widget.Toast(ctx);
toast.setView(text);
toast.show();

}}));}
const Button = android.widget.Button;
const PopupWindow = android.widget.PopupWindow;
const Gravity = android.view.Gravity;
//Bitmap
const Bitmap = android.graphics.Bitmap;
const BitmapFactory = android.graphics.BitmapFactory;
const BitmapDrawable = android.graphics.drawable.BitmapDrawable;
const Canvas = android.graphics.Canvas;

ChatDrawable = function () {
var Icon = BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/gui/rocketL.png"));
var bitmap = Bitmap.createBitmap(Icon, 1, 1, 175, 135);
var bit = Bitmap.createScaledBitmap(bitmap, DP * 350, DP * 270, false);

return new BitmapDrawable(bit);
};
EngineDrawable = function () {
var Icon = BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/items-opaque/engine_tier1engine_0.png"));
var bitmap = Bitmap.createBitmap(Icon, 0, 0, 31, 31);
var bit = Bitmap.createScaledBitmap(bitmap, DP * 30, DP * 30, false);

return new BitmapDrawable(bit);
};
WingDrawable = function () {
var Icon = BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/items-opaque/rocketFins_0.png"));
var bitmap = Bitmap.createBitmap(Icon, 0, 0, 31, 31);
var bit = Bitmap.createScaledBitmap(bitmap, DP * 30, DP * 30, false);

return new BitmapDrawable(bit);
};
PlatingDrawable = function () {
var Icon = BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/items-opaque/heavyPlating_0.png"));
var bitmap = Bitmap.createBitmap(Icon, 0, 0, 31, 31);
var bit = Bitmap.createScaledBitmap(bitmap, DP * 30, DP * 30, false);

return new BitmapDrawable(bit);
};
ConeDrawable = function () {
var Icon = BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/items-opaque/noseCone_0.png"));
var bitmap = Bitmap.createBitmap(Icon, 0, 0, 31, 31);
var bit = Bitmap.createScaledBitmap(bitmap, DP * 30, DP * 30, false);

return new BitmapDrawable(bit);
};
ParachuteDrawable = function () {
var Icon = BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/items-opaque/parachute_black_0.png"));
var bitmap = Bitmap.createBitmap(Icon, 0, 0, 15, 15);
var bit = Bitmap.createScaledBitmap(bitmap, DP * 30, DP * 30, false);

return new BitmapDrawable(bit);
};
RocketDrawable = function () {
var Icon = BitmapFactory.decodeStream(ModPE.openInputStreamFromTexturePack("images/items-opaque/rocket1_0.png"));
var bitmap = Bitmap.createBitmap(Icon, 0, 0, 36, 36);
var bit = Bitmap.createScaledBitmap(bitmap, DP * 30, DP * 30, false);
//138 92 44×44
return new BitmapDrawable(bit);
};

//이미지
var wing1 = null, wing2 = null, wing3 = null, wing4 = null, engine = null, plate1 = null, plate2 = null, plate3 = null, plate4 = null, plate5 = null, plate6 = null, plate7 = null, plate8 = null, cone = null, parachute = null, rocket = null;
var wingN = 0, engineN = 0, plateN = 0, coneN = 0, parachuteN = 0;
function NasaWorkBench (){
	ctx.runOnUiThread(new java.lang.Runnable({ run: function() {
try{
var lay2 = new android.widget.LinearLayout(ctx);
lay2.setOrientation(1);
var scr = new android.widget.ScrollView(ctx); 
scr.addView(lay2);
var window = new android.widget.PopupWindow(scr, DP * 350, DP * 270, false);
window.setBackgroundDrawable(
ChatDrawable());
window.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 50, DP * 50);

var btn1 = new android.widget.LinearLayout (ctx);
var btn2 = new android.widget.LinearLayout (ctx);
var btn3 = new android.widget.LinearLayout (ctx);
var btn4 = new android.widget.LinearLayout (ctx);
var btn5 = new android.widget.LinearLayout (ctx);
var btn6 = new android.widget.LinearLayout (ctx);
var btn7 = new android.widget.LinearLayout (ctx);
var btn8 = new android.widget.LinearLayout (ctx);
var btn9 = new android.widget.LinearLayout (ctx);
var btn10 = new android.widget.LinearLayout (ctx);
var btn11 = new android.widget.LinearLayout (ctx);
var btn12 = new android.widget.LinearLayout (ctx);
var btn13 = new android.widget.LinearLayout (ctx);
var btn14 = new android.widget.LinearLayout (ctx);
var btn15 = new android.widget.LinearLayout (ctx);
 engine = new android.widget.PopupWindow(btn1, DP * 30, DP * 30, false);
engine.setBackgroundDrawable(
EngineDrawable());

 wing1 = new android.widget.PopupWindow(btn2, DP * 30, DP * 30, false);
wing1.setBackgroundDrawable(
WingDrawable());

 wing2 = new android.widget.PopupWindow(btn3, DP * 30, DP * 30, false);
wing2.setBackgroundDrawable(
WingDrawable());

 wing3 = new android.widget.PopupWindow(btn4, DP * 30, DP * 30, false);
wing3.setBackgroundDrawable(
WingDrawable());

 wing4 = new android.widget.PopupWindow(btn5, DP * 30, DP * 30, false); 
wing4.setBackgroundDrawable(
WingDrawable());

plate1 = new android.widget.PopupWindow(btn6, DP * 30, DP * 30, false); 
plate1.setBackgroundDrawable(
PlatingDrawable());
plate2 = new android.widget.PopupWindow(btn7, DP * 30, DP * 30, false); 
plate2.setBackgroundDrawable(
PlatingDrawable());
plate3 = new android.widget.PopupWindow(btn8, DP * 30, DP * 30, false); 
plate3.setBackgroundDrawable(
PlatingDrawable());
plate4 = new android.widget.PopupWindow(btn9, DP * 30, DP * 30, false); 
plate4.setBackgroundDrawable(
PlatingDrawable());
plate5 = new android.widget.PopupWindow(btn10, DP * 30, DP * 30, false); 
plate5.setBackgroundDrawable(
PlatingDrawable());
plate6 = new android.widget.PopupWindow(btn11, DP * 30, DP * 30, false); 
plate6.setBackgroundDrawable(
PlatingDrawable());
plate7 = new android.widget.PopupWindow(btn12, DP * 30, DP * 30, false); 
plate7.setBackgroundDrawable(
PlatingDrawable());
plate8 = new android.widget.PopupWindow(btn13, DP * 30, DP * 30, false); 
plate8.setBackgroundDrawable(
PlatingDrawable());
cone = new android.widget.PopupWindow(btn14, DP * 30, DP * 30, false); 
cone.setBackgroundDrawable(ConeDrawable());
parachute = new android.widget.PopupWindow(btn15, DP * 30, DP * 30, false); 
parachute.setBackgroundDrawable(ParachuteDrawable());
 rocket_I = new android.widget.ImageView(ctx); rocket_I.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
rocket_I.setBackgroundDrawable(RocketDrawable ());
rocket_I.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 44, DP * 44));
rocket = new android.widget.PopupWindow(rocket_I, DP * 44, DP * 44, false); 
//39 54
var lay = new android.widget.LinearLayout (ctx);
lay.setOrientation (1);
var iv1 = new android.widget.ImageView(ctx);

iv1.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
iv1.setBackgroundDrawable(EngineDrawable ());
iv1.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 40, DP * 40));
lay.addView (iv1);

var iv2 = new android.widget.ImageView(ctx);
iv2.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
iv2.setBackgroundDrawable(WingDrawable ());
iv2.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 40, DP * 40));
lay.addView (iv2);
var iv3 = new android.widget.ImageView(ctx);
iv3.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
iv3.setBackgroundDrawable(PlatingDrawable ());
iv3.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 40, DP * 40));
lay.addView (iv3);
var iv4 = new android.widget.ImageView(ctx);
iv4.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
iv4.setBackgroundDrawable(ConeDrawable ());
iv4.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 40, DP * 40));
lay.addView (iv4);
var iv5 = new android.widget.ImageView(ctx);
iv5.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
iv5.setBackgroundDrawable(ParachuteDrawable ());
iv5.setLayoutParams(new android.widget.LinearLayout.LayoutParams(DP * 40, DP * 40));
lay.addView (iv5);
var AddWindow = android.widget.PopupWindow(lay, DP * 40, DP * 200, false);
AddWindow.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, DP * 400, DP * 60);
/*
ModPE.setItem (522, "engine_tier1engine", 0, "Tier1 Engine", 1);
ModPE.setItem (531, "heavyPlating", 0, "Heavy Plating");
ModPE.setItem (537, "noseCone", 0, "NoseCone");
559 rocketfin
*/
iv1.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (engineN == 1){
	toast ("이미 엔진을 주입했습니다");
	return;
}if (gia (522, 0) == 0){
	toast ("보유한 엔진이 없습니다.");
	return;
}
engineN = 1;
toast ("엔진을 주입했습니다.");
engine.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 146, DP * 266);
if (engineN == 1 && wingN == 4 && plateN == 8 && parachuteN == 1 && coneN == 1){	rocket.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 326, DP * 234);
	toast ("부품을 모두 주입했습니다.");
}

}
}));
iv2.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (wingN == 4){
	toast ("이미 날개 4개를 주입했습니다");
	return;
}if (gia (559, 0) == 0 && wingN == 0){
	toast ("보유한 날개가 없습니다.");
	return;
}if (gia (559, 0) < 2 && wingN == 1){
	toast ("보유한 날개가 없습니다.");
	return;
}if (gia (559, 0) < 3 && wingN == 2){
	toast ("보유한 날개가 없습니다.");
	return;
}if (gia (559, 0) < 4 && wingN == 3){
	toast ("보유한 날개가 없습니다.");
	return;
}
if (wingN == 0){
wingN += 1;
toast ("날개를 주입했습니다.");
wing1.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 92, DP * 232);
return;
}if (wingN == 1){
wingN += 1;
toast ("날개를 주입했습니다.");
wing2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 92, DP * 266);
return;
}if (wingN == 2){
wingN += 1;
toast ("날개를 주입했습니다.");
wing3.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 200, DP * 230);
return;
}if (wingN == 3){
wingN += 1;
toast ("날개를 주입했습니다.");
wing4.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 200, DP * 266);
if (engineN == 1 && wingN == 4 && plateN == 8 && parachuteN == 1 && coneN == 1){	rocket.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 326, DP * 234);
	toast ("부품을 모두 주입했습니다.");
}
return;
}

}
}));
iv3.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (plateN == 8){
	toast ("이미 강철 플레이트 8개를 주입했습니다");
	return;
}if (gia (531, 0) < 1 && plateN == 0){
	toast ("보유한 플레이트가 없습니다.");
	return;
}if (gia (531, 0) < 2 && plateN == 1){
	toast ("보유한 플레이트가 없습니다.");
	return;
}if (gia (531, 0) < 3 && plateN == 2){
	toast ("보유한 플레이트가 없습니다.");
	return;
}if (gia (531, 0) < 4 && plateN == 3){
	toast ("보유한 플레이트가 없습니다.");
	return;
}if (gia (531, 0) < 5 && plateN == 4){
	toast ("보유한 플레이트가 없습니다.");
	return;
}if (gia (531, 0) < 6 && plateN == 5){
	toast ("보유한 플레이트가 없습니다.");
	return;
}if (gia (531, 0) < 8 && plateN == 7){
	toast ("보유한 플레이트가 없습니다.");
	return;
}if (gia (531, 0) < 1 && plateN == 0){
	toast ("보유한 플레이트가 없습니다.");
	return;
}
if (plateN == 0){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate1.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 128, DP * 122);
return;
}if (plateN == 1){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 162, DP * 122);
return;
}
if (plateN == 2){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate3.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 128, DP * 158);
return;
}
if (plateN == 3){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate4.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 162, DP * 158);
return;
}
if (plateN == 4){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate5.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 128, DP * 194);
return;
}
if (plateN == 5){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate6.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 162, DP * 194);
return;
}
if (plateN == 6){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate7.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 128, DP * 230);
return;
}
if (plateN == 7){
plateN += 1;
toast ("플레이트를 주입했습니다.");
plate8.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 162, DP * 230);
if (engineN == 1 && wingN == 4 && plateN == 8 && parachuteN == 1 && coneN == 1){	rocket.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 326, DP * 234);
	toast ("부품을 모두 주입했습니다.");
}
return;
}
}
}));
iv4.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (coneN == 1){
	toast ("이미 noseCone을 주입했습니다");
	return;
}if (gia (537, 0) == 0){
	toast ("보유한 noseCone이 없습니다.");
	return;
}
coneN = 1;
toast ("noseCone을 주입했습니다.");
cone.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 146, DP * 86);
if (engineN == 1 && wingN == 4 && plateN == 8 && parachuteN == 1 && coneN == 1){	rocket.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 326, DP * 234);
	toast ("부품을 모두 주입했습니다.");
}
}
}));
iv5.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
if (parachuteN == 1){
	toast ("이미 낙하산을 주입했습니다");
	return;
}if (gia (557, 0) == 0){
	toast ("보유한 낙하산이 없습니다.");
	return;
}
parachuteN = 1;
toast ("낙하산을 주입했습니다.");
parachute.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 236, DP * 72);
if (engineN == 1 && wingN == 4 && plateN == 8 && parachuteN == 1 && coneN == 1){	rocket.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.TOP | android.view.Gravity.LEFT, DP * 326, DP * 234);
	toast ("부품을 모두 주입했습니다.");
}
}
}));
rocket_I.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
rmi (522, 1);
rmi (559, 4);
rmi (531, 8);
rmi (537, 1);
rmi (557, 1);
addItemInventory (601, 1, 0);
wingN = 0, engineN = 0, plateN = 0, coneN = 0, parachuteN = 0;
	close (window);
	close (engine);
	close (wing1);
	close (wing2);
	close (wing3);
	close (wing4);
	close (plate1);
	close (plate2);
	close (plate3);
	close (plate4);
	close (plate5);
	close (plate6);
	close (plate7);
	close (plate8);
	close (cone);
	close (parachute);
close (rocket);
Exit_W.dismiss ();
Exit_W = null;
AddWindow.dismiss ();
AddWindow = null;
}
}));



//138 92
var Exit_B = new android.widget.Button(ctx); 
Exit_B.setOnClickListener(new android.view.View.OnClickListener({
onClick: function () {
	wingN = 0, engineN = 0, plateN = 0, coneN = 0, parachuteN = 0;
	close (window);
	close (engine);
	close (wing1);
	close (wing2);
	close (wing3);
	close (wing4);
	close (plate1);
	close (plate2);
	close (plate3);
	close (plate4);
	close (plate5);
	close (plate6);
	close (plate7);
	close (plate8);
	close (cone);
	close (parachute);
close (rocket);
Exit_W.dismiss ();
Exit_W = null;
AddWindow.dismiss ();
AddWindow = null;
}
}));
Exit_B.setText("X");
var Exit_W = android.widget.PopupWindow(Exit_B, DP * 50, DP * 50, false);
Exit_W.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.TOP, 0, 0);
}
catch(error) 
{
clientMessage("[에러발생]"+error);
}
}}));
}
function close (Window) {
ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
if(Window != null) {
Window.dismiss(); //존재할때 닫음.
}
}}));
}
//175 219
function createNinePatch( bitmap, x, y, xx, yy)
{
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var NO_COLOR = 0x00000001;
var buffer = java.nio.ByteBuffer.allocate(56).order(java.nio.ByteOrder.nativeOrder());
buffer.put(0x01);
buffer.put(0x02);
buffer.put(0x02); 
buffer.put(0x02);
buffer.putInt(0); 
buffer.putInt(0); 
buffer.putInt(0);
buffer.putInt(0);
buffer.putInt(0); 
buffer.putInt(0);
buffer.putInt(0);
buffer.putInt(y-1); 
buffer.putInt(yy);
buffer.putInt(x-1); 
buffer.putInt(xx); 
buffer.putInt(NO_COLOR);
buffer.putInt(NO_COLOR); 
var drawable = new android.graphics.drawable.NinePatchDrawable(ctx.getResources(), bitmap, buffer.array(), new android.graphics.Rect(), null);
return drawable;
}
function steveRender(renderer)
{
var Model= renderer.getModel(); 

var head = Model.getPart("head"); 
var body = Model.getPart("body"); 
var rightArm = Model.getPart("rightArm"); 
var leftArm = Model.getPart("leftArm");
var rightLeg = Model.getPart("rightLeg");
var leftLeg = Model.getPart("leftLeg");

head.clear();
body.clear();
rightArm.clear();
leftArm.clear();
rightLeg.clear();
leftLeg.clear();

var X = 0;
var Y = 0;
var Z = 0;
/*
body.addBox(-21.5 + X, 26.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-21.5 + X, 26.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-21.5 + X, 26.5 + Y, -9.5 + Z, 1, 1, 1, 1.5);
body.addBox(-17.5 + X, 26.5 + Y, -13.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 26.5 + Y, -13.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 26.5 + Y, -13.5 + Z, 1, 1, 1, 1.5);*/
body.addBox(-21.5 + X, 18.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 18.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 18.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 18.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 18.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 18.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 18.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 18.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 18.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 18.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 18.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 18.5 + Y, 18.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 18.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 18.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 18.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 18.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 18.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 18.5 + Y, -13.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 18.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 18.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 18.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 18.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 18.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 18.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 18.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 18.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 18.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 18.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(10.5 + X, 18.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-21.5 + X, 14.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 14.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 14.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 14.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 14.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 14.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 14.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 14.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 14.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 14.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 14.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 14.5 + Y, 18.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 14.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 14.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 14.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 14.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 14.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 14.5 + Y, -13.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 14.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 14.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 14.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 14.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 14.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 14.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 14.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 14.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 14.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 14.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(10.5 + X, 14.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-21.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-17.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 10.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 10.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 10.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 10.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 10.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 10.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 10.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 10.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, 18.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, 14.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, -9.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 10.5 + Y, -13.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 10.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 10.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 10.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 10.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 10.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 10.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 10.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 10.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(6.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(10.5 + X, 10.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-21.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-17.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 6.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 6.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 6.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 6.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 6.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 6.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 6.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 6.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, 18.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, 14.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, -9.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 6.5 + Y, -13.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 6.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 6.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 6.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 6.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 6.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 6.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 6.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 6.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(6.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(10.5 + X, 6.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 2.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 2.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 2.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 2.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, 2.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 2.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 2.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 2.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 2.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, 2.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 2.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 2.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 2.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 2.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, 2.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 2.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 2.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 2.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 2.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, 2.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 2.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 2.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 2.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 2.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, 2.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -1.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -1.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -1.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -1.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -1.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -1.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -1.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -1.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -1.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -1.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -1.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -1.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -1.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -1.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -1.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -1.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -1.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -1.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -1.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -1.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -1.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -1.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -1.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -1.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -1.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -5.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -5.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -5.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -5.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -5.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -5.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -5.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -5.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -5.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -5.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -5.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -5.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -5.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -5.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -5.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -5.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -5.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -5.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -5.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -5.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -5.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -5.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -5.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -5.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -5.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -9.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -9.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -9.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -9.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -9.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -9.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -9.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -9.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -9.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -9.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -9.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -9.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -9.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -9.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -9.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -9.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -9.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -9.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -9.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -9.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -9.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -9.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -9.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -9.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -9.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -13.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -13.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-13.5 + X, -13.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -13.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -13.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -13.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -13.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -13.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -13.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -13.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -13.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -13.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -13.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -13.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -13.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -13.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -13.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -13.5 + Y, -5.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -13.5 + Y, 10.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -13.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -13.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(2.5 + X, -13.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -17.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -17.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-9.5 + X, -17.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -17.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -17.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -17.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -17.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -17.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -17.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);

body.addBox(-9.5 + X, -21.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);

body.addBox(-5.5 + X, -21.5 + Y, 6.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -21.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);
body.addBox(-5.5 + X, -21.5 + Y, -1.5 + Z, 1, 1, 1, 1.5);
body.addBox(-1.5 + X, -21.5 + Y, 2.5 + Z, 1, 1, 1, 1.5);


}

var steve = Renderer.createHumanoidRenderer();

steveRender(steve);